from __future__ import annotations

from dataclasses import asdict

from backend_v2.chat.context import ConversationContext
from backend_v2.database.repositories import CitationRepository, ConversationRepository, MessageRepository
from backend_v2.database.connection import SessionLocal
from backend_v2.retrieval.citation_builder import CitationRef


class ChatPersistenceService:
    def persist_turn(
        self,
        context: ConversationContext,
        *,
        user_query: str,
        answer: str,
        citations: tuple[CitationRef, ...] = (),
        provider: str | None = None,
        model: str | None = None,
        found: bool = True,
    ) -> None:
        db = SessionLocal()
        try:
            conv_repo = ConversationRepository(db)
            message_repo = MessageRepository(db)
            citation_repo = CitationRepository(db)
            conversation = conv_repo.get_or_create(
                conversation_id=context.conversation_id,
                mode=context.mode,
                user_id=context.user_id,
                grade_id=context.grade_id,
                subject_id=context.subject_id,
                course_id=context.course_id,
                chapter_id=context.chapter_id,
                lesson_id=context.lesson_id,
            )
            message_repo.create(
                conversation_id=conversation.id,
                role="user",
                content=user_query,
                metadata_json={"mode": context.mode.value},
            )
            assistant = message_repo.create(
                conversation_id=conversation.id,
                role="assistant",
                content=answer,
                metadata_json={
                    "found": found,
                    "provider": provider,
                    "model": model,
                    "citation_count": len(citations),
                },
            )
            for citation in citations:
                citation_repo.create(
                    message_id=assistant.id,
                    source_id=citation.source_id,
                    title=citation.title,
                    url=citation.url,
                    page=citation.page,
                    start_time_seconds=citation.start_time_seconds,
                    end_time_seconds=citation.end_time_seconds,
                    preview=citation.preview,
                    metadata_json=citation.metadata or {},
                )
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def history(self, conversation_id: str, *, limit: int = 100) -> list[dict]:
        db = SessionLocal()
        try:
            rows = MessageRepository(db).list(conversation_id, limit=limit)
            citations = CitationRepository(db)
            result = []
            for message in rows:
                result.append({
                    "id": message.id,
                    "role": message.role,
                    "content": message.content,
                    "metadata": message.metadata_json,
                    "created_at": message.created_at.isoformat(),
                    "citations": [
                        {
                            "id": c.id,
                            "source_id": c.source_id,
                            "title": c.title,
                            "url": c.url,
                            "page": c.page,
                            "start_time_seconds": c.start_time_seconds,
                            "end_time_seconds": c.end_time_seconds,
                            "preview": c.preview,
                            "metadata": c.metadata_json,
                        }
                        for c in citations.list_for_message(message.id)
                    ],
                })
            return result
        finally:
            db.close()
