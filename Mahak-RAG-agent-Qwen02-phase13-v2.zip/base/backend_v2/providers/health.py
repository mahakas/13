from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import StrEnum

from backend_v2.core.enums import Capability


class CircuitState(StrEnum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass(slots=True)
class HealthState:
    state: CircuitState = CircuitState.CLOSED
    failures: int = 0
    successes: int = 0
    cooldown_until: datetime | None = None
    last_error: str | None = None


class ProviderHealthManager:
    def __init__(self, failure_threshold: int = 3, cooldown_seconds: int = 30) -> None:
        self.failure_threshold = failure_threshold
        self.cooldown_seconds = cooldown_seconds
        self._states: dict[tuple[str, Capability], HealthState] = {}

    def state(self, provider: str, capability: Capability) -> HealthState:
        return self._states.setdefault((provider, capability), HealthState())

    def is_available(self, provider: str, capability: Capability) -> bool:
        state = self.state(provider, capability)
        if state.state is CircuitState.OPEN:
            if state.cooldown_until and state.cooldown_until <= datetime.now(timezone.utc):
                state.state = CircuitState.HALF_OPEN
                return True
            return False
        return True

    def record_success(self, provider: str, capability: Capability) -> None:
        state = self.state(provider, capability)
        state.state = CircuitState.CLOSED
        state.successes += 1
        state.failures = 0
        state.cooldown_until = None
        state.last_error = None

    def record_failure(self, provider: str, capability: Capability, error: Exception) -> None:
        state = self.state(provider, capability)
        state.failures += 1
        state.last_error = str(error)
        if state.failures >= self.failure_threshold:
            state.state = CircuitState.OPEN
            state.cooldown_until = datetime.now(timezone.utc) + timedelta(seconds=self.cooldown_seconds)

    def states(self) -> dict[tuple[str, Capability], HealthState]:
        return dict(self._states)
