from __future__ import annotations

from typing import Any

import requests

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse


class AnthropicAdapter:
    def __init__(
        self,
        api_key: str,
        *,
        default_model: str = "claude-3-5-sonnet-latest",
        base_url: str = "https://api.anthropic.com/v1",
        timeout_seconds: float = 60.0,
        session: requests.Session | None = None,
    ) -> None:
        self.provider_name = "anthropic"
        self.api_key = api_key
        self.default_model = default_model
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.session = session or requests.Session()

    def supports(self, capability: Capability) -> bool:
        return capability in {Capability.CHAT, Capability.VISION, Capability.STRUCTURED_OUTPUT}

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        payload = request.payload if isinstance(request.payload, dict) else {"messages": request.payload}
        messages = payload.get("messages", [])
        system_parts = [m["content"] for m in messages if m.get("role") == "system" and isinstance(m.get("content"), str)]
        user_messages = [m for m in messages if m.get("role") != "system"]
        body: dict[str, Any] = {
            "model": request.model,
            "max_tokens": int(payload.get("max_tokens", 2048)),
            "messages": user_messages,
        }
        if system_parts:
            body["system"] = "\n\n".join(system_parts)
        if payload.get("temperature") is not None:
            body["temperature"] = payload["temperature"]
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        response = self.session.post(f"{self.base_url}/messages", headers=headers, json=body, timeout=self.timeout_seconds)
        response.raise_for_status()
        data = response.json()
        blocks = data.get("content") or []
        text = "".join(
            block.get("text", "")
            for block in blocks
            if block.get("type") == "text"
        )
        # Some test doubles and gateways return a simple string in content.
        if not text and isinstance(blocks, str):
            text = blocks
        return ProviderResponse(text, self.provider_name, request.model, metadata={"raw": data})

    def health_check(self, capability: Capability | None = None) -> bool:
        # Anthropic has no cheap generic anonymous health endpoint; perform a
        # conservative credential presence check and let real calls validate access.
        return bool(self.api_key)
