from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from backend_v2.providers.adapters.factory import build_external_registry_from_env
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator


@dataclass(frozen=True, slots=True)
class LiveRuntimeConfig:
    timeout_seconds: float = 60.0
    max_attempts: int = 3
    backoff_seconds: float = 0.25
    rate_limit_requests: int = 30
    rate_limit_window_seconds: float = 60.0


def build_live_orchestrator(*, fallback_registry=None) -> ProviderOrchestrator:
    """Build a real provider orchestrator from environment variables.

    When no real credentials are configured, the caller may provide a fallback
    registry (typically the deterministic local/mock registry used in tests).
    """
    registry = build_external_registry_from_env()
    if fallback_registry is not None:
        for provider in fallback_registry.providers():
            if registry.get(provider.adapter.provider_name) is None:
                registry.register(
                    provider.adapter,
                    priority=provider.priority,
                    enabled=provider.enabled,
                    models=provider.profile.models,
                )
    config = LiveRuntimeConfig(
        timeout_seconds=float(os.getenv("PROVIDER_TIMEOUT_SECONDS", "60")),
        max_attempts=int(os.getenv("PROVIDER_MAX_ATTEMPTS", "3")),
        backoff_seconds=float(os.getenv("PROVIDER_RETRY_BACKOFF_SECONDS", "0.25")),
        rate_limit_requests=int(os.getenv("PROVIDER_RATE_LIMIT_REQUESTS", "30")),
        rate_limit_window_seconds=float(os.getenv("PROVIDER_RATE_LIMIT_WINDOW_SECONDS", "60")),
    )
    health = ProviderHealthManager(
        failure_threshold=int(os.getenv("PROVIDER_CIRCUIT_FAILURE_THRESHOLD", "3")),
        cooldown_seconds=int(os.getenv("PROVIDER_CIRCUIT_COOLDOWN_SECONDS", "30")),
    )
    return ProviderOrchestrator(
        registry,
        health,
        max_attempts=config.max_attempts,
        retry_backoff_seconds=config.backoff_seconds,
        rate_limit_requests=config.rate_limit_requests,
        rate_limit_window_seconds=config.rate_limit_window_seconds,
    )
