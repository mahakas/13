from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any, Callable

import requests

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.rate_limit import RateLimiter
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.resolver import ProviderResolver, ProviderSelection


@dataclass(frozen=True, slots=True)
class OrchestrationResult:
    response: ProviderResponse
    attempts: int
    selection: ProviderSelection


def _is_retryable(exc: Exception) -> bool:
    if isinstance(exc, (requests.Timeout, requests.ConnectionError)):
        return True
    if isinstance(exc, requests.HTTPError):
        response = getattr(exc, "response", None)
        status = getattr(response, "status_code", None)
        return status in {408, 409, 425, 429, 500, 502, 503, 504}
    return False


class ProviderOrchestrator:
    """Executes a capability request with real retry, rate limiting and failover."""

    def __init__(
        self,
        registry: ProviderRegistry,
        health: ProviderHealthManager | None = None,
        *,
        max_attempts: int = 3,
        retry_backoff_seconds: float = 0.25,
        sleeper: Callable[[float], None] = time.sleep,
        random_fn: Callable[[], float] = random.random,
        rate_limit_requests: int = 30,
        rate_limit_window_seconds: float = 60.0,
    ) -> None:
        self.health = health or ProviderHealthManager()
        self.registry = registry
        self.resolver = ProviderResolver(registry, self.health)
        self.max_attempts = max(1, max_attempts)
        self.retry_backoff_seconds = max(0.0, retry_backoff_seconds)
        self._sleep = sleeper
        self._random = random_fn
        self._limiters: dict[str, RateLimiter] = {}
        self._rate_limit_requests = max(1, rate_limit_requests)
        self._rate_limit_window_seconds = max(0.001, rate_limit_window_seconds)

    def _limiter(self, provider_name: str) -> RateLimiter:
        limiter = self._limiters.get(provider_name)
        if limiter is None:
            limiter = RateLimiter(self._rate_limit_requests, self._rate_limit_window_seconds)
            self._limiters[provider_name] = limiter
        return limiter

    def execute(self, capability: Capability, payload: Any, *, metadata: dict[str, Any] | None = None) -> OrchestrationResult:
        errors: list[str] = []
        attempts = 0
        metadata = dict(metadata or {})

        for selection in self.resolver.rank(capability):
            if attempts >= self.max_attempts:
                break
            provider_name = selection.provider.adapter.provider_name
            request = ProviderRequest(
                capability=capability,
                model=selection.model,
                payload=payload,
                metadata=metadata,
            )
            provider_attempt = 0
            while attempts < self.max_attempts:
                attempts += 1
                provider_attempt += 1
                try:
                    self._limiter(provider_name).acquire()
                    started = time.perf_counter()
                    response = selection.provider.adapter.execute(request)
                    latency_ms = response.latency_ms
                    if latency_ms is None:
                        latency_ms = (time.perf_counter() - started) * 1000
                        response = ProviderResponse(
                            output=response.output,
                            provider=response.provider,
                            model=response.model,
                            latency_ms=latency_ms,
                            metadata=response.metadata,
                        )
                    self.health.record_success(provider_name, capability)
                    return OrchestrationResult(response=response, attempts=attempts, selection=selection)
                except Exception as exc:
                    errors.append(f"{provider_name}/{selection.model}: {type(exc).__name__}: {exc}")
                    self.health.record_failure(provider_name, capability, exc)
                    if not _is_retryable(exc) or attempts >= self.max_attempts:
                        break
                    delay = self.retry_backoff_seconds * (2 ** (provider_attempt - 1))
                    delay *= 0.5 + self._random()
                    if delay:
                        self._sleep(delay)
                    # Re-check provider health before another attempt.
                    if not self.health.is_available(provider_name, capability):
                        break

        joined = "; ".join(errors) if errors else "no compatible healthy provider"
        raise RuntimeError(f"Provider orchestration failed for {capability.value}: {joined}")
