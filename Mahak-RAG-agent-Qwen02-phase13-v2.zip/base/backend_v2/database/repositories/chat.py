from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend_v2.database.models import Citation, Conversation, Message


class ConversationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, conversation_id: str) -> Conversation | None:
        return self.db.get(Conversation, conversation_id)

    def get_or_create(self, *, conversation_id: str, mode, user_id: str | None = None, **scope) -> Conversation:
        conversation = self.get(conversation_id)
        if conversation is not None:
            return conversation
        conversation = Conversation(
            id=conversation_id,
            user_id=user_id,
            mode=mode,
            grade_id=scope.get("grade_id"),
            subject_id=scope.get("subject_id"),
            course_id=scope.get("course_id"),
            chapter_id=scope.get("chapter_id"),
            lesson_id=scope.get("lesson_id"),
        )
        self.db.add(conversation)
        self.db.flush()
        return conversation

    def touch(self, conversation: Conversation) -> Conversation:
        self.db.flush()
        return conversation


class MessageRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, *, conversation_id: str, role: str, content: str, metadata_json: dict | None = None) -> Message:
        message = Message(
            conversation_id=conversation_id,
            role=role,
            content=content,
            metadata_json=metadata_json or {},
        )
        self.db.add(message)
        self.db.flush()
        return message

    def list(self, conversation_id: str, *, limit: int = 100) -> list[Message]:
        stmt = (
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at.asc())
            .limit(limit)
        )
        return list(self.db.scalars(stmt).all())


class CitationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, *, message_id: str, source_id: str | None, title: str, url: str | None = None,
               page: int | None = None, start_time_seconds: int | None = None,
               end_time_seconds: int | None = None, preview: str | None = None,
               metadata_json: dict | None = None) -> Citation:
        citation = Citation(
            message_id=message_id,
            source_id=source_id,
            title=title,
            url=url,
            page=page,
            start_time_seconds=start_time_seconds,
            end_time_seconds=end_time_seconds,
            preview=preview,
            metadata_json=metadata_json or {},
        )
        self.db.add(citation)
        self.db.flush()
        return citation

    def list_for_message(self, message_id: str) -> list[Citation]:
        stmt = select(Citation).where(Citation.message_id == message_id).order_by(Citation.id.asc())
        return list(self.db.scalars(stmt).all())

    def list_for_conversation(self, conversation_id: str) -> list[Citation]:
        stmt = (
            select(Citation)
            .join(Message, Citation.message_id == Message.id)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at.asc(), Citation.id.asc())
        )
        return list(self.db.scalars(stmt).all())
