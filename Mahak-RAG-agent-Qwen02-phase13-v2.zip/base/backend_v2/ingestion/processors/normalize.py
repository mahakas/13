from __future__ import annotations

import re
import unicodedata

from backend_v2.ingestion.document import ExtractedDocument


class TextNormalizer:
    def normalize(self, document: ExtractedDocument) -> ExtractedDocument:
        text = unicodedata.normalize("NFC", document.text or "")
        text = text.replace("\u00a0", " ").replace("\r\n", "\n").replace("\r", "\n")
        text = "\n".join(line.strip() for line in text.split("\n"))
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        return ExtractedDocument(
            source_type=document.source_type,
            text=text,
            title=document.title.strip(),
            metadata=dict(document.metadata),
            locations=document.locations,
            requires=document.requires,
        )
