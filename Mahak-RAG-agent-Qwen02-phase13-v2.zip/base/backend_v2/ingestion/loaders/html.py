from __future__ import annotations

from bs4 import BeautifulSoup

from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.base import require_exists


class HtmlLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        html = analysis.path.read_text(encoding="utf-8-sig", errors="replace")
        soup = BeautifulSoup(html, "html.parser")
        for node in soup(["script", "style", "noscript"]):
            node.decompose()
        title = soup.title.get_text(" ", strip=True) if soup.title else analysis.path.stem
        text = soup.get_text("\n", strip=True)
        return ExtractedDocument(
            source_type=analysis.source_type,
            text=text,
            title=title,
            metadata={"path": str(analysis.path), "url": soup.find("meta", attrs={"property": "og:url"}).get("content") if soup.find("meta", attrs={"property": "og:url"}) else None},
        )
