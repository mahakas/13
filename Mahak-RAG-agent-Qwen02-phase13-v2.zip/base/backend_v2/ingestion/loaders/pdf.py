from __future__ import annotations

from pypdf import PdfReader

from backend_v2.core.enums import Capability
from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument, SourceLocation
from backend_v2.ingestion.loaders.base import require_exists


class PdfLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        reader = PdfReader(str(analysis.path))
        texts: list[str] = []
        locations: list[SourceLocation] = []
        for number, page in enumerate(reader.pages, start=1):
            page_text = (page.extract_text() or "").strip()
            if page_text:
                texts.append(page_text)
                locations.append(SourceLocation(page=number))
        metadata = {
            "path": str(analysis.path),
            "pages": len(reader.pages),
            "extracted_pages": len(texts),
        }
        requires = frozenset({Capability.OCR, Capability.VISION}) if not texts and len(reader.pages) else frozenset()
        return ExtractedDocument(
            source_type=analysis.source_type,
            text="\n\n".join(texts),
            title=analysis.path.stem,
            metadata=metadata,
            locations=tuple(locations),
            requires=requires,
        )
