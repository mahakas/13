# Mahak AI v2 — Phase 3 Ingestion

Phase 3 adds a deterministic multimodal ingestion foundation.

## Supported input types

- TXT / Markdown
- DOCX
- PDF
- HTML / HTM
- JPG / JPEG / PNG / WEBP / BMP / GIF
- MP4 / MOV / MKV / WEBM / AVI

## Pipeline

`analyze -> load -> normalize -> chunk -> quality-check -> capability declaration`

This phase intentionally does **not** call LLM, vision, embedding providers, or a vector database. For images, scanned PDFs, and video, it declares the provider capabilities still required (Vision, OCR, Transcription). Those provider calls belong to the next provider-orchestration phase.

## Example

```python
from pathlib import Path
from backend_v2.ingestion import IngestionPipeline

result = IngestionPipeline().process(Path("lesson.pdf"))
print(result.document.title)
print(len(result.chunks))
print(result.required_capabilities)
```
