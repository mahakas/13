from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from backend_v2.core.enums import Capability, SourceType
from backend_v2.ingestion.analyzer import FileAnalysis, FileAnalyzer
from backend_v2.ingestion.document import ContentChunk, ExtractedDocument
from backend_v2.ingestion.loaders import LoaderRegistry
from backend_v2.ingestion.processors import QualityChecker, TextChunker, TextNormalizer


@dataclass(frozen=True, slots=True)
class IngestionResult:
    analysis: FileAnalysis
    document: ExtractedDocument
    chunks: tuple[ContentChunk, ...]
    required_capabilities: frozenset[Capability]
    warnings: tuple[str, ...] = field(default_factory=tuple)

    @property
    def ready_for_embedding(self) -> bool:
        return bool(self.chunks)

    @property
    def needs_provider_processing(self) -> bool:
        return bool(self.required_capabilities)


class IngestionPipeline:
    """Deterministic ingestion foundation.

    This phase deliberately does not call LLM/vision/embedding providers or any
    vector database. It produces normalized documents and metadata-rich chunks
    and declares any additional capabilities required for provider processing.
    """

    def __init__(self, *, chunk_size: int = 900, overlap: int = 120) -> None:
        self.analyzer = FileAnalyzer()
        self.loaders = LoaderRegistry()
        self.normalizer = TextNormalizer()
        self.chunker = TextChunker(chunk_size=chunk_size, overlap=overlap)
        self.quality = QualityChecker()

    def analyze(self, path: Path) -> FileAnalysis:
        return self.analyzer.analyze(path)

    def process(self, path: Path) -> IngestionResult:
        path = Path(path)
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(path)
        analysis = self.analyzer.analyze(path)
        document = self.loaders.load(analysis)
        document = self.normalizer.normalize(document)
        chunks = self.chunker.chunk(document)
        report = self.quality.check(document, chunks)
        required = frozenset(set(analysis.requires) | set(document.requires))
        warnings = report.warnings
        if not report.accepted_for_indexing and not required:
            raise ValueError(f"Input produced no usable content: {path}")
        return IngestionResult(
            analysis=analysis,
            document=document,
            chunks=tuple(chunks),
            required_capabilities=required,
            warnings=warnings,
        )

    def supported_types(self) -> Iterable[SourceType]:
        return tuple(self.analyzer.EXTENSIONS.values())
