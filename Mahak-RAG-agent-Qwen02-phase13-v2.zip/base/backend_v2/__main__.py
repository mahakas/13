from backend_v2.database import create_all


if __name__ == "__main__":
    create_all()
    print("Mahak AI v2 core initialized.")
