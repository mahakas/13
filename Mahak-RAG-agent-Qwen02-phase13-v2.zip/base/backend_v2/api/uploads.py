from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from backend_v2.chat.session_files import SessionFileService
from backend_v2.core.config import settings
from backend_v2.core.enums import ChatMode
from backend_v2.retrieval.session_index import SessionIndexService
from backend_v2.runtime import runtime
from backend_v2.database.connection import SessionLocal
from backend_v2.schemas.uploads import SessionUploadResponse

router = APIRouter(prefix="/uploads", tags=["uploads"])


@router.post("/session", response_model=SessionUploadResponse)
async def upload_session_file(
    conversation_id: str = Form(...),
    mode: ChatMode = Form(ChatMode.GENERAL),
    grade_id: str | None = Form(None),
    subject_id: str | None = Form(None),
    course_id: str | None = Form(None),
    chapter_id: str | None = Form(None),
    lesson_id: str | None = Form(None),
    file: UploadFile = File(...),
):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    db = SessionLocal()
    try:
        service = SessionFileService(
            db,
            storage_root=settings.storage_dir,
            session_index=SessionIndexService(runtime.vector_store, runtime.embedding),
        )
        result = service.save_upload(
            conversation_id=conversation_id,
            mode=mode.value,
            filename=file.filename or "upload.bin",
            content=content,
            mime_type=file.content_type,
            grade_id=grade_id,
            subject_id=subject_id,
            course_id=course_id,
            chapter_id=chapter_id,
            lesson_id=lesson_id,
        )
        return SessionUploadResponse(
            session_file_id=result.session_file.id,
            source_id=result.source.id,
            conversation_id=conversation_id,
            filename=result.session_file.filename,
            source_type=result.source.source_type,
            status=result.session_file.status,
            size_bytes=result.session_file.size_bytes,
            ready_for_context=result.ready_for_context,
            required_capabilities=list(result.session_file.required_capabilities),
            warnings=list(result.warnings),
            chunk_count=len(result.session_file.chunks_json),
            indexed_chunks=int(result.session_file.metadata_json.get("indexed_chunks", 0) or 0),
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    finally:
        db.close()


@router.get("/session/{conversation_id}")
def list_session_files(conversation_id: str):
    from sqlalchemy import select
    from backend_v2.database.models import SessionFile

    db = SessionLocal()
    try:
        rows = db.scalars(select(SessionFile).where(SessionFile.conversation_id == conversation_id).order_by(SessionFile.created_at.desc())).all()
        return [
            {
                "session_file_id": row.id,
                "filename": row.filename,
                "status": row.status,
                "size_bytes": row.size_bytes,
                "required_capabilities": row.required_capabilities,
                "chunk_count": len(row.chunks_json),
                "ready_for_context": bool(row.extracted_text),
            }
            for row in rows
        ]
    finally:
        db.close()
