from __future__ import annotations

import re
from dataclasses import dataclass

from backend_v2.vectorstores.base import VectorHit

_PERSIAN_SPACES = re.compile(r"\s+")
_PUNCT = re.compile(r"[\u200c\u200d\u200e\u200f.,،؛;:!?؟()\[\]{}\"'`]+")


def normalize_text(text: str) -> str:
    text = str(text).replace("ي", "ی").replace("ك", "ک").replace("ۀ", "هٔ")
    text = text.replace("\u0640", "")
    text = _PUNCT.sub(" ", text)
    return _PERSIAN_SPACES.sub(" ", text).strip().lower()


def lexical_score(query: str, document: str) -> float:
    q_tokens = set(normalize_text(query).split())
    d_tokens = set(normalize_text(document).split())
    if not q_tokens or not d_tokens:
        return 0.0
    overlap = len(q_tokens & d_tokens) / len(q_tokens)
    return max(0.0, min(1.0, overlap))


@dataclass(frozen=True, slots=True)
class HybridScore:
    vector_score: float
    lexical_score: float
    final_score: float


class HybridReranker:
    """Lightweight lexical + vector reranker; provider reranking can replace this later."""

    def __init__(self, *, vector_weight: float = 0.75, lexical_weight: float = 0.25) -> None:
        total = vector_weight + lexical_weight
        if total <= 0:
            raise ValueError("Reranker weights must sum to a positive value")
        self.vector_weight = vector_weight / total
        self.lexical_weight = lexical_weight / total

    def score(self, query: str, hit: VectorHit) -> HybridScore:
        v = max(0.0, min(1.0, float(hit.score)))
        l = lexical_score(query, hit.document)
        final = self.vector_weight * v + self.lexical_weight * l
        return HybridScore(v, l, final)

    def rerank(self, query: str, hits: list[VectorHit], *, top_k: int | None = None) -> list[VectorHit]:
        scored: list[tuple[float, VectorHit]] = []
        for hit in hits:
            scores = self.score(query, hit)
            metadata = dict(hit.metadata)
            metadata["vector_score"] = round(scores.vector_score, 6)
            metadata["lexical_score"] = round(scores.lexical_score, 6)
            scored.append((scores.final_score, VectorHit(hit.id, scores.final_score, hit.document, metadata)))
        scored.sort(key=lambda item: (item[0], item[1].id), reverse=True)
        results = [item[1] for item in scored]
        return results[:top_k] if top_k is not None else results
