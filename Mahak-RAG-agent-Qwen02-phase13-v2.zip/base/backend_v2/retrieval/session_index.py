from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from backend_v2.vectorstores.base import VectorRecord, VectorStore
from backend_v2.vectorstores.embedding import EmbeddingService


@dataclass(frozen=True, slots=True)
class SessionIndexResult:
    indexed: int
    record_ids: tuple[str, ...]
    collection: str


class SessionIndexService:
    """Indexes approved session-file chunks into an isolated conversation-search collection."""

    collection = "mahak_sessions"

    def __init__(self, vector_store: VectorStore, embedding_service: EmbeddingService) -> None:
        self.vector_store = vector_store
        self.embedding_service = embedding_service

    def index_chunks(self, chunks: Iterable[dict]) -> SessionIndexResult:
        items = [dict(chunk) for chunk in chunks if str(chunk.get("text", "")).strip()]
        if not items:
            return SessionIndexResult(0, (), self.collection)

        texts = [str(item["text"]) for item in items]
        embedding = self.embedding_service.embed(texts)
        records: list[VectorRecord] = []
        for item, vector in zip(items, embedding.vectors):
            metadata = dict(item.get("metadata") or {})
            metadata.update(
                {
                    "session_file_id": item.get("session_file_id"),
                    "source_id": item.get("source_id"),
                    "title": item.get("title") or metadata.get("title") or "فایل کاربر",
                    "scope": "session",
                    "embedding_provider": embedding.provider,
                    "embedding_model": embedding.model,
                    "embedding_dimension": embedding.dimension,
                }
            )
            location = item.get("location") or {}
            for key in ("page", "start_time_seconds", "end_time_seconds", "url"):
                if key in location and location[key] is not None:
                    metadata[key] = location[key]
            records.append(
                VectorRecord(
                    id=str(item.get("id")),
                    embedding=vector,
                    document=texts[len(records)],
                    metadata=metadata,
                )
            )
        self.vector_store.upsert(records, collection=self.collection)
        return SessionIndexResult(len(records), tuple(record.id for record in records), self.collection)

    def delete_file(self, session_file_id: str) -> int:
        # InMemory/VectorStore contract exposes delete by ids, so derive ids from metadata is backend-specific.
        # This is intentionally a no-op until a generic metadata-delete operation exists.
        return 0
