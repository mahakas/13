from __future__ import annotations

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.factory import build_external_registry_from_env
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.live import build_live_orchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.memory import InMemoryVectorStore


class V2Runtime:
    """Process runtime with real providers when credentials are configured.

    Deterministic mock providers remain as the final local fallback for tests and
    development, but real providers are preferred whenever their environment
    credentials are present.
    """

    def __init__(self) -> None:
        self.registry = ProviderRegistry()
        self.health = ProviderHealthManager()
        self.vector_store = InMemoryVectorStore()
        self._register_local_fallbacks()
        self._register_real_providers()
        self.embedding_orchestrator = self._build_orchestrator()
        self.llm_orchestrator = self._build_orchestrator()
        self.embedding = EmbeddingService(self.embedding_orchestrator)

    def _register_local_fallbacks(self) -> None:
        self.registry.register(
            MockProviderAdapter(
                "default-embedding",
                {Capability.EMBEDDING},
                default_model="embed-v1",
                embedding_dimension=8,
            ),
            priority=1000,
        )
        self.registry.register(
            MockProviderAdapter(
                "default-chat",
                {Capability.CHAT},
                default_model="chat-v1",
                handler=lambda payload: "پاسخ آموزشی تولیدشده بر اساس منابع بازیابی‌شده.",
            ),
            priority=1000,
        )

    def _register_real_providers(self) -> None:
        real = build_external_registry_from_env()
        for provider in real.providers():
            self.registry.register(
                provider.adapter,
                priority=provider.priority,
                enabled=provider.enabled,
                models=provider.profile.models,
            )

    def _build_orchestrator(self) -> ProviderOrchestrator:
        from os import getenv
        return ProviderOrchestrator(
            self.registry,
            self.health,
            max_attempts=int(getenv("PROVIDER_MAX_ATTEMPTS", "3")),
            retry_backoff_seconds=float(getenv("PROVIDER_RETRY_BACKOFF_SECONDS", "0.25")),
            rate_limit_requests=int(getenv("PROVIDER_RATE_LIMIT_REQUESTS", "30")),
            rate_limit_window_seconds=float(getenv("PROVIDER_RATE_LIMIT_WINDOW_SECONDS", "60")),
        )


runtime = V2Runtime()
