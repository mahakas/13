# Web Search Layer

فاز ۸ یک قرارداد مستقل برای Web Search اضافه می‌کند.

- `WebSearchAdapter`: قرارداد Provider-agnostic برای جست‌وجوی وب.
- `WebSearchResult`: نتیجه استاندارد با title/url/snippet.
- `InMemoryWebSearchAdapter`: Adapter قطعی برای تست و توسعه محلی.

در نسخه بعد، Adapterهای واقعی Web Search بدون تغییر در `GeneralChatService` اضافه می‌شوند.
