from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class WebSearchResult:
    title: str
    url: str
    snippet: str
    source: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class WebSearchAdapter(Protocol):
    provider_name: str

    def search(self, query: str, *, top_k: int = 5) -> list[WebSearchResult]: ...

    def health_check(self) -> bool: ...


class InMemoryWebSearchAdapter:
    """Deterministic web adapter for tests/local development."""

    provider_name = "memory-web"

    def __init__(self, results: dict[str, list[WebSearchResult]] | None = None) -> None:
        self.results = results or {}

    def search(self, query: str, *, top_k: int = 5) -> list[WebSearchResult]:
        query = str(query).strip()
        exact = self.results.get(query)
        if exact is not None:
            return exact[:top_k]
        tokens = {token.lower() for token in query.split() if token}
        scored: list[tuple[int, WebSearchResult]] = []
        for key, values in self.results.items():
            score = len(tokens & {t.lower() for t in key.split()})
            if score:
                scored.extend((score, item) for item in values)
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _, item in scored[:top_k]]

    def health_check(self) -> bool:
        return True
