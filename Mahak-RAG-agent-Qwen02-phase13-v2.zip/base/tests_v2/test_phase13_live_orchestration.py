from __future__ import annotations

import requests

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry


class RetryableAdapter:
    provider_name = "retryable"
    default_model = "retry-model"

    def __init__(self):
        self.calls = 0

    def supports(self, capability):
        return capability is Capability.CHAT

    def execute(self, request):
        self.calls += 1
        if self.calls == 1:
            response = requests.Response()
            response.status_code = 429
            raise requests.HTTPError("rate limited", response=response)
        from backend_v2.providers.contracts import ProviderResponse
        return ProviderResponse("ok", self.provider_name, request.model)

    def health_check(self, capability=None):
        return True


def test_orchestrator_retries_retryable_provider_error_without_secret_logging():
    registry = ProviderRegistry()
    adapter = RetryableAdapter()
    registry.register(adapter, priority=1)
    health = ProviderHealthManager(failure_threshold=5)
    sleeps = []
    orchestrator = ProviderOrchestrator(
        registry,
        health,
        max_attempts=2,
        retry_backoff_seconds=0.01,
        sleeper=sleeps.append,
        random_fn=lambda: 0.0,
        rate_limit_requests=100,
    )
    result = orchestrator.execute(Capability.CHAT, {"messages": []})
    assert result.response.output == "ok"
    assert adapter.calls == 2
    assert sleeps
    assert health.state("retryable", Capability.CHAT).failures == 0


def test_orchestrator_falls_back_to_next_provider_on_terminal_error():
    class Broken(MockProviderAdapter):
        def execute(self, request):
            raise RuntimeError("provider down")

    registry = ProviderRegistry()
    registry.register(Broken("broken", {Capability.CHAT}), priority=1)
    registry.register(MockProviderAdapter("backup", {Capability.CHAT}, handler=lambda _: "fallback"), priority=2)
    result = ProviderOrchestrator(registry, ProviderHealthManager(failure_threshold=1), max_attempts=2, rate_limit_requests=100).execute(Capability.CHAT, {"messages": []})
    assert result.response.provider == "backup"


def test_rate_limit_and_timeout_settings_are_configurable(monkeypatch):
    monkeypatch.setenv("PROVIDER_RATE_LIMIT_REQUESTS", "7")
    monkeypatch.setenv("PROVIDER_RATE_LIMIT_WINDOW_SECONDS", "2")
    from backend_v2.providers.live import LiveRuntimeConfig
    cfg = LiveRuntimeConfig(
        rate_limit_requests=7,
        rate_limit_window_seconds=2,
    )
    assert cfg.rate_limit_requests == 7
    assert cfg.rate_limit_window_seconds == 2
