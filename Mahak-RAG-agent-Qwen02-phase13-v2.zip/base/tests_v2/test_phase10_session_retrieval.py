from pathlib import Path

from fastapi.testclient import TestClient

import backend_v2.api.uploads as uploads_api
from backend_v2.api.app import create_app
from backend_v2.core.config import settings
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.runtime import runtime
from dataclasses import replace


def test_uploaded_txt_is_indexed_and_retrievable(tmp_path, monkeypatch):
    monkeypatch.setattr(uploads_api, "settings", replace(settings, storage_dir=tmp_path))
    runtime.vector_store._collections.clear()
    client = TestClient(create_app())
    response = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-phase10", "mode": "educational"},
        files={"file": ("lesson.txt", "قانون دوم نیوتن می گوید نیرو برابر جرم ضربدر شتاب است.", "text/plain")},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["indexed_chunks"] >= 1

    retrieval = RetrievalService(runtime.vector_store, runtime.embedding)
    result = retrieval.retrieve(
        RetrievalRequest(
            "نیروی وارد بر جسم چیست؟",
            RetrievalScope(source_ids=(payload["source_id"],)),
            "mahak_sessions",
            top_k=4,
            min_score=0.0,
        )
    )
    assert result.found is True
    assert any(hit.metadata.get("source_id") == payload["source_id"] for hit in result.accepted)


def test_educational_chat_uses_uploaded_session_file(tmp_path, monkeypatch):
    monkeypatch.setattr(uploads_api, "settings", replace(settings, storage_dir=tmp_path))
    runtime.vector_store._collections.clear()
    client = TestClient(create_app())
    upload = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-phase10-chat", "mode": "educational"},
        files={"file": ("lesson.txt", "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.", "text/plain")},
    )
    assert upload.status_code == 200, upload.text
    info = upload.json()

    chat = client.post(
        "/api/chat/educational",
        json={
            "conversation_id": "conv-phase10-chat",
            "query": "قانون دوم نیوتن را توضیح بده",
            "session_file_ids": [info["session_file_id"]],
        },
    )
    assert chat.status_code == 200, chat.text
    payload = chat.json()
    assert payload["found"] is True
    assert payload["retrieval_count"] >= 1
    assert payload["citations"]
    assert payload["citations"][0]["source_id"] == info["source_id"]


def test_session_scope_does_not_leak_between_conversations(tmp_path, monkeypatch):
    monkeypatch.setattr(uploads_api, "settings", replace(settings, storage_dir=tmp_path))
    runtime.vector_store._collections.clear()
    client = TestClient(create_app())
    first = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-a", "mode": "educational"},
        files={"file": ("a.txt", "فقط در گفتگوی اول: فرمول آلفا.", "text/plain")},
    ).json()
    second = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-b", "mode": "educational"},
        files={"file": ("b.txt", "فقط در گفتگوی دوم: فرمول بتا.", "text/plain")},
    ).json()

    retrieval = RetrievalService(runtime.vector_store, runtime.embedding)
    result = retrieval.retrieve(
        RetrievalRequest(
            "فرمول آلفا چیست؟",
            RetrievalScope(session_file_ids=(second["session_file_id"],)),
            "mahak_sessions",
            top_k=5,
            min_score=0.0,
        )
    )
    assert result.found is True
    assert all(hit.metadata.get("source_id") == second["source_id"] for hit in result.accepted)
    assert all(hit.metadata.get("source_id") != first["source_id"] for hit in result.accepted)
