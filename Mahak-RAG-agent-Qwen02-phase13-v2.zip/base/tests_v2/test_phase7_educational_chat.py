from backend_v2.chat.context import ConversationContext
from backend_v2.chat.educational import NO_KNOWLEDGE_MESSAGE, EducationalChatService
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.retrieval.service import RetrievalService
from backend_v2.vectorstores.base import VectorRecord
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.memory import InMemoryVectorStore


def _service():
    registry = ProviderRegistry()
    embedding = MockProviderAdapter("embed", {Capability.EMBEDDING}, default_model="embed-v1", embedding_dimension=8)

    def chat_handler(payload):
        assert payload["mode"] == "educational"
        assert payload["messages"][0]["role"] == "system"
        assert "قانون دوم نیوتن" in payload["messages"][1]["content"]
        return "قانون دوم نیوتن رابطهٔ بین نیرو، جرم و شتاب را بیان می‌کند."

    chat = MockProviderAdapter("chat", {Capability.CHAT}, chat_handler, default_model="chat-v1")
    registry.register(embedding, priority=1)
    registry.register(chat, priority=1)
    health = ProviderHealthManager()
    orchestrator = ProviderOrchestrator(registry, health)
    retrieval = RetrievalService(InMemoryVectorStore(), EmbeddingService(orchestrator))
    return EducationalChatService(retrieval, orchestrator, collection="kb", min_score=0.10)


def _context():
    return ConversationContext(
        conversation_id="conv-1",
        user_id="u-1",
        mode=ChatMode.EDUCATIONAL,
        grade_id="g10",
        subject_id="physics",
        course_id="course-physics",
    )


def test_educational_chat_retrieves_and_answers_with_citations():
    service = _service()
    service.retrieval.vector_store.upsert(
        [VectorRecord(
            "chunk-1",
            [0.2] * 8,
            "قانون دوم نیوتن: نیرو برابر جرم ضربدر شتاب است.",
            {"grade_id": "g10", "subject_id": "physics", "course_id": "course-physics", "source_id": "src-1", "title": "فیزیک دهم", "url": "https://example.test/book.pdf", "page": 42},
        )],
        collection="kb",
    )
    result = service.ask(_context(), "قانون دوم نیوتن چیست؟")
    assert result.found
    assert result.provider == "chat"
    assert result.model == "chat-v1"
    assert result.retrieval_count == 1
    assert result.citations[0].page == 42
    assert result.citations[0].url.endswith("book.pdf")


def test_educational_chat_is_closed_world_when_no_source_is_found():
    service = _service()
    result = service.ask(_context(), "پایتخت فرانسه چیست؟")
    assert not result.found
    assert result.answer == NO_KNOWLEDGE_MESSAGE
    assert result.citations == ()


def test_educational_chat_rejects_general_context():
    service = _service()
    context = _context()
    context.mode = ChatMode.GENERAL
    try:
        service.ask(context, "سؤال")
    except ValueError as exc:
        assert "educational" in str(exc).lower()
    else:
        raise AssertionError("general context should be rejected")


def test_context_history_is_updated():
    service = _service()
    service.retrieval.vector_store.upsert(
        [VectorRecord("x", [0.3] * 8, "ریاضی پایه", {"grade_id": "g10"})],
        collection="kb",
    )
    context = ConversationContext("c", None, ChatMode.EDUCATIONAL, grade_id="g10")
    service.ask(context, "این موضوع چیست؟")
    assert context.messages[-2]["role"] == "user"
    assert context.messages[-1]["role"] == "assistant"


def test_context_builder_is_safe_on_empty_hits():
    from backend_v2.chat.context_builder import build_answer_context
    result = build_answer_context([])
    assert result.passages == ()
    assert result.citations == ()


def test_chat_api_exposes_educational_endpoint():
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    client = TestClient(create_app())
    response = client.post(
        "/api/chat/educational",
        json={"conversation_id": "api-1", "query": "یک سؤال آموزشی"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["found"] is False
    assert "این سؤال" in data["answer"]
